// ── Webhooks (hardcoded) ─────────────────────────────────────────────────────
const WEBHOOK_IMPORT = 'https://hook.eu2.make.com/1e33hohrk84vh54zaxtnfks0efapdzez';
const WEBHOOK_JOBS   = 'https://hook.eu2.make.com/8yxjhtnpqnfovz98vuosnzdhvx3mcdio';
const WEBHOOK_TEAM   = 'https://hook.eu2.make.com/t0ql4jventxqwxbgpc5mmcwlttg5p8ys';

// ── Supabase Config ───────────────────────────────────────────────────────────
const SUPABASE_URL = 'https://wvcjcjpulktryagwbwkb.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind2Y2pjanB1bGt0cnlhZ3did2tiIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODA0Nzk1NTAsImV4cCI6MjA5NjA1NTU1MH0.6cqY_s0X-ymSD_F_xlwd2kmxVflBOsI02hj9lJImC2M';


// ── Auth / Login ──────────────────────────────────────────────────────────────
async function checkAuth() {
  // Einfacher Flag — kein Ablauf, einmal eingeloggt bleibt eingeloggt
  const result = await chrome.storage.local.get('talnt_logged_in');
  if (result.talnt_logged_in === true) {
    showApp();
    await initApp();
  } else {
    showLogin();
  }
}

function showLogin() {
  document.getElementById('login-screen').style.display = 'flex';
  document.getElementById('main-app').style.display = 'none';
}

function showApp() {
  document.getElementById('login-screen').style.display = 'none';
  document.getElementById('main-app').style.display = 'block';
}

async function login(email, password) {
  const btn = $('btn-login');
  btn.disabled = true; btn.textContent = '⏳ Anmelden...';
  $('login-error').textContent = '';

  try {
    const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_ANON_KEY,
      },
      body: JSON.stringify({ email, password })
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.error_description || data.msg || 'Login fehlgeschlagen');

    // Einfachen Flag setzen — kein Token, kein Ablauf
    await chrome.storage.local.set({ talnt_logged_in: true });

    showApp();
    await initApp();
  } catch(e) {
    $('login-error').textContent = e.message;
  }

  btn.disabled = false; btn.textContent = 'Anmelden';
}

// Bind login button
document.getElementById('btn-login').addEventListener('click', () => {
  const email = $('login-email').value.trim();
  const password = $('login-password').value;
  if (!email || !password) { $('login-error').textContent = 'Bitte E-Mail und Passwort eingeben'; return; }
  login(email, password);
});

// Enter key support
document.getElementById('login-password').addEventListener('keydown', e => {
  if (e.key === 'Enter') {
    const email = $('login-email').value.trim();
    const password = $('login-password').value;
    if (email && password) login(email, password);
  }
});

// Show login immediately while checking session
document.getElementById('login-screen').style.display = 'flex';

// talnt. CRM Import — Popup
const $ = id => document.getElementById(id);
const S = { get: k => chrome.storage.local.get(k).then(r => r[k]), set: (k,v) => chrome.storage.local.set({[k]:v}) };
const send = msg => chrome.runtime.sendMessage(msg);
const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

let allCandidates = [], selectedCandidates = [];

function toast(msg, type='ok') {
  const t = $('toast');
  t.textContent = msg;
  t.style.cssText = `display:block;background:${type==='ok'?'#052e16':'#2d0a2e'};color:${type==='ok'?'#4ade80':'#f87171'};border:1px solid ${type==='ok'?'#166534':'#7f1d1d'}`;
  setTimeout(() => t.style.display='none', 3000);
}

// ── Tabs ──────────────────────────────────────────────────────────────────────
document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('[id^="tab-"]').forEach(c => c.classList.add('hidden'));
    tab.classList.add('active');
    $(`tab-${tab.dataset.tab}`).classList.remove('hidden');
  });
});

// ── Team / Owner ──────────────────────────────────────────────────────────────
async function loadTeam() {
  const team = await S.get('team_members') || [];
  const webhookTeam = await S.get('team_from_webhook') || [];
  const myName = await S.get('my_name') || '';
  const myId = await S.get('my_ownerid') || '';

  // Build owner dropdown
  const sel = $('sel-owner');
  sel.innerHTML = '<option value="">— Owner wählen —</option>';
  if (myName) {
    const opt = document.createElement('option');
    opt.value = myId || myName;
    opt.textContent = myName + ' (ich)';
    opt.selected = true;
    sel.appendChild(opt);
  }

  // Webhook team members — Recruit CRM ID als Value, nur Name sichtbar
  webhookTeam.forEach(m => {
    const recruitCrmId = m['Recruit CRM ID'] || m.recruit_crm_id || m.recruitCrmId || m.id || '';
    const name = m.Name || m.name || m.full_name || '';
    if (!name) return;
    const opt = document.createElement('option');
    opt.value = recruitCrmId; // Recruit CRM ID — unsichtbar, wird mitgesendet
    opt.textContent = name;   // nur Name sichtbar
    sel.appendChild(opt);
  });

  // Manually added team members
  team.forEach(m => {
    const opt = document.createElement('option');
    opt.value = m.id || m.name;
    opt.textContent = m.name;
    sel.appendChild(opt);
  });

  // Render team list in settings
  renderTeamList(team);
}

function renderTeamList(team) {
  const list = $('team-list');
  if (!team.length) {
    list.innerHTML = '<div style="font-size:11px;color:var(--text3)">Noch keine weiteren Mitglieder</div>';
    return;
  }
  list.innerHTML = team.map((m, i) => `
    <div style="display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid var(--border);font-size:12px">
      <span style="flex:1;color:var(--text)">${esc(m.name)}</span>
      <span style="color:var(--text3);font-size:11px">${esc(m.id||'')}</span>
      <button onclick="removeMember(${i})" style="background:none;border:none;cursor:pointer;color:#f87171;font-size:14px;padding:0 2px">×</button>
    </div>`).join('');
}

window.removeMember = async function(i) {
  let team = await S.get('team_members') || [];
  team.splice(i, 1);
  await S.set('team_members', team);
  await loadTeam();
  toast('Entfernt');
};

$('btn-add-team').addEventListener('click', async () => {
  const name = $('in-team-name').value.trim();
  const id   = $('in-team-id').value.trim();
  if (!name) { toast('Bitte Namen eingeben', 'err'); return; }
  let team = await S.get('team_members') || [];
  team.push({ name, id });
  await S.set('team_members', team);
  $('in-team-name').value = ''; $('in-team-id').value = '';
  await loadTeam();
  toast(`${name} hinzugefügt ✓`);
});

// ── Profile ───────────────────────────────────────────────────────────────────
$('btn-save-profile').addEventListener('click', async () => {
  const name = $('in-my-name').value.trim();
  const id   = $('in-my-ownerid').value.trim();
  if (!name) { toast('Bitte Namen eingeben', 'err'); return; }
  await S.set('my_name', name);
  await S.set('my_ownerid', id);
  await loadTeam();
  toast('Profil gespeichert ✓');
  $('profile-status').innerHTML = '<span style="color:#4ade80">✓ Gespeichert</span>';
});

// ── Extract ───────────────────────────────────────────────────────────────────
$('btn-extract').addEventListener('click', async () => {
  const btn = $('btn-extract');
  btn.disabled = true; btn.textContent = '⏳ Lade...';
  $('extract-status').textContent = '';

  try {
    const result = await send({ type: 'EXTRACT_CANDIDATES' });
    if (!result?.ok) throw new Error(result?.error || 'Unbekannter Fehler');
    if (!result.candidates?.length) throw new Error('Keine Kandidaten gefunden — XING oder LinkedIn Recruiter öffnen');

    allCandidates = result.candidates;
    selectedCandidates = [...allCandidates];
    renderCandidates();
    $('candidates-section').classList.remove('hidden');
    $('btn-import').disabled = false;
    $('extract-status').innerHTML = `<span style="color:#4ade80">✓ ${allCandidates.length} Kandidaten aus ${result.source} geladen</span>`;
    toast(`${allCandidates.length} Kandidaten geladen ✓`);
  } catch(e) {
    $('extract-status').innerHTML = `<span style="color:#f87171">✗ ${esc(e.message)}</span>`;
    toast(e.message, 'err');
  }
  btn.disabled = false; btn.textContent = '⬇ Kandidaten aus aktivem Tab laden';
});

function renderCandidates() {
  $('candidates-list').innerHTML = allCandidates.map((c, i) => {
    const sel = selectedCandidates.includes(c);
    const tagClass = c.source === 'XING' ? 'tag-xing' : 'tag-li';
    return `<div class="cand-card ${sel?'selected':''}" data-idx="${i}">
      <input type="checkbox" class="cand-cb" data-idx="${i}" ${sel?'checked':''} style="margin-top:2px;accent-color:#8B5CF6;flex-shrink:0">
      <div style="flex:1;min-width:0">
        <div class="cand-name">${esc(c.fullName)}</div>
        <div class="cand-meta">${esc(c.jobTitle||'')}${c.company?' · '+esc(c.company):''}</div>
        <div class="cand-meta">${esc(c.location||'')}</div>
        <span class="tag ${tagClass}">${c.source}</span>
      </div>
    </div>`;
  }).join('');
  updateSelectCount();

  $('candidates-list').querySelectorAll('.cand-card').forEach(card => {
    card.addEventListener('click', e => {
      if (e.target.tagName === 'INPUT') return;
      toggleCandidate(+card.dataset.idx, card);
    });
  });
  $('candidates-list').querySelectorAll('.cand-cb').forEach(cb => {
    cb.addEventListener('change', () => toggleCandidate(+cb.dataset.idx, cb.closest('.cand-card')));
  });
}

function toggleCandidate(i, card) {
  const c = allCandidates[i];
  const idx = selectedCandidates.indexOf(c);
  const cb = card.querySelector('.cand-cb');
  if (idx === -1) { selectedCandidates.push(c); card.classList.add('selected'); if(cb) cb.checked=true; }
  else { selectedCandidates.splice(idx,1); card.classList.remove('selected'); if(cb) cb.checked=false; }
  updateSelectCount();
}

function updateSelectCount() {
  $('select-count').textContent = `${selectedCandidates.length} ausgewählt`;
  $('btn-import').disabled = selectedCandidates.length === 0;
}

$('btn-select-all').addEventListener('click', () => { selectedCandidates = [...allCandidates]; renderCandidates(); });
$('btn-deselect-all').addEventListener('click', () => { selectedCandidates = []; renderCandidates(); });

// ── Import ────────────────────────────────────────────────────────────────────
$('btn-import').addEventListener('click', async () => {
  if (!selectedCandidates.length) { toast('Keine Kandidaten ausgewählt', 'err'); return; }
  const btn = $('btn-import');
  btn.disabled = true; btn.textContent = '⏳ Importiere...';
  $('import-result').classList.remove('hidden');
  $('result-list').innerHTML = '';
  $('progress-fill').style.width = '0%';

  const jobSel = $('sel-jobtitle');
  const jobTitle = jobSel.value;
  const jobId = jobSel.selectedOptions[0]?.dataset?.jobId || '';
  const jobLocation = jobSel.selectedOptions[0]?.dataset?.jobLocation || '';
  const jobDisplayTitle = jobSel.selectedOptions[0]?.dataset?.jobTitle || jobTitle;
  // Manual job title as fallback if no hot job selected
  const manualJobTitle = $('sel-jobtitle-manual')?.value || '';
  const finalJobTitle = jobDisplayTitle || manualJobTitle;
  const ownerVal = $('sel-owner').value;
  const ownerName = $('sel-owner').selectedOptions[0]?.textContent?.replace(' (ich)','') || '';
  const testMode = $('chk-test').checked;
  await S.set('test_mode', testMode);

  try {
    const result = await send({
      type: 'CREATE_CANDIDATES',
      candidates: selectedCandidates,
      ownerId: ownerVal,
      ownerName,
      jobTitleOverride: finalJobTitle,
      jobId,
      jobLocation,
    });
    if (!result?.ok) throw new Error(result?.error || 'Fehler');

    const total = result.results.length;
    result.results.forEach((r, i) => {
      $('progress-fill').style.width = `${Math.round((i+1)/total*100)}%`;
      const div = document.createElement('div');
      div.className = 'result-item';
      div.innerHTML = r.ok
        ? `<span style="color:#4ade80">✓</span> <span>${esc(r.name)}</span>${r.test?'<span style="color:#a78bfa;font-size:10px;margin-left:auto">Test</span>':''}`
        : `<span style="color:#f87171">✗</span> <span>${esc(r.name)}</span><span style="color:#f87171;font-size:10px;margin-left:auto">${esc(r.error||'')}</span>`;
      $('result-list').appendChild(div);
    });
    const ok = result.results.filter(r=>r.ok).length;
    toast(`${ok} von ${total} importiert ✓`);
  } catch(e) {
    toast(e.message, 'err');
  }
  btn.disabled = false; btn.textContent = '✓ Ausgewählte in Recruit CRM importieren';
  updateSelectCount();
});



// ── Hot Jobs ──────────────────────────────────────────────────────────────────
async function loadHotJobs() {
  const btn = $('btn-load-jobs');
  const status = $('jobs-status');
  const sel = $('sel-jobtitle');

  const url = WEBHOOK_JOBS;

  btn.disabled = true; btn.textContent = '⏳';
  status.innerHTML = '<span style="color:#a78bfa">Lade Jobs...</span>';

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'get_jobs', timestamp: new Date().toISOString() })
    });
    if (!res.ok) throw new Error('HTTP ' + res.status);

    const data = await res.json();
    // Structure: [{JSON: [...]}] or direct array
    let jobs = [];
    if (Array.isArray(data) && data[0]?.JSON) {
      jobs = data[0].JSON;
    } else if (Array.isArray(data) && data[0]?.id !== undefined) {
      jobs = data;
    } else {
      jobs = data.jobs || data.data || data.results || [];
    }

    if (!jobs.length) throw new Error('Keine Jobs gefunden');

    // Sort descending by ID
    const sorted = [...jobs].sort((a, b) => {
      const idA = parseInt(a.id || a.job_id || a.ID || 0);
      const idB = parseInt(b.id || b.job_id || b.ID || 0);
      return idB - idA;
    });

    window._allJobs = sorted; // store for filtering
    renderJobOptions(sorted);

    // Cache jobs
    await S.set('cached_jobs', sorted);
    await S.set('jobs_loaded_at', Date.now());

    status.innerHTML = `<span style="color:#4ade80">✓ ${jobs.length} Jobs geladen</span>`;
  } catch(e) {
    status.innerHTML = `<span style="color:#f87171">✗ ${esc(e.message)}</span>`;
  }

  btn.disabled = false; btn.textContent = '🔄 Jobs laden';
}


// ── Webhook Test ──────────────────────────────────────────────────────────────
async function testAllWebhooks() {
  const btn = $('btn-test-all-webhooks');
  const results = $('webhook-test-results');
  btn.disabled = true; btn.textContent = '⏳ Teste...';
  results.innerHTML = '';

  const webhooks = [
    { name: 'Import Webhook (Kandidaten)', url: WEBHOOK_IMPORT },
    { name: 'Jobs Webhook (Hot Jobs)', url: WEBHOOK_JOBS },
    { name: 'Mitarbeiter Webhook (Owner)', url: WEBHOOK_TEAM },
  ];

  for (const wh of webhooks) {
    const row = document.createElement('div');
    row.style.cssText = 'padding:6px 0;border-bottom:1px solid var(--border);font-size:12px;display:flex;align-items:center;gap:8px';
    row.innerHTML = `<span style="color:var(--text3)">⏳</span><span style="flex:1;color:var(--text2)">${esc(wh.name)}</span>`;
    results.appendChild(row);

    try {
      const res = await fetch(wh.url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ test: true, source: 'talnt. CRM Import', timestamp: new Date().toISOString() })
      });
      if (res.ok) {
        row.innerHTML = `<span style="color:#4ade80">✓</span><span style="flex:1;color:var(--text)">${esc(wh.name)}</span><span style="color:#4ade80;font-size:10px">Erreichbar</span>`;
      } else {
        row.innerHTML = `<span style="color:#f87171">✗</span><span style="flex:1;color:var(--text)">${esc(wh.name)}</span><span style="color:#f87171;font-size:10px">HTTP ${res.status}</span>`;
      }
    } catch(e) {
      row.innerHTML = `<span style="color:#f87171">✗</span><span style="flex:1;color:var(--text)">${esc(wh.name)}</span><span style="color:#f87171;font-size:10px">${esc(e.message)}</span>`;
    }
  }

  btn.disabled = false; btn.textContent = '🧪 Webhooks testen';
}



// ── Team aus Webhook laden ────────────────────────────────────────────────────
async function loadTeamFromWebhook() {
  try {
    const res = await fetch(WEBHOOK_TEAM, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'get_team', timestamp: new Date().toISOString() })
    });
    if (!res.ok) return;
    const data = await res.json();
    // Handle nested structure: [{body: {results: [...]}}] or direct array
    let members = [];
    if (Array.isArray(data) && data[0]?.body?.results) {
      members = data[0].body.results;
    } else if (Array.isArray(data) && data[0]?.Name) {
      members = data;
    } else {
      members = data.results || data.members || data.team || [];
    }
    if (!members.length) return;

    // Cache team
    await S.set('team_from_webhook', members);

    // Update owner dropdown
    await loadTeam();
  } catch(e) {
    console.log('[talnt] Team webhook error:', e.message);
  }
}

// ── Job Filter ────────────────────────────────────────────────────────────────
function renderJobOptions(jobs) {
  const sel = document.getElementById('sel-jobtitle');
  if (!sel) return;
  const current = sel.value;
  sel.innerHTML = '<option value="">— Job auswählen (optional) —</option>';
  jobs.forEach(job => {
    const id = job.id || job.job_id || job.ID || '';
    const title = job.title || job.job_title || job.name || job.Titel || '';
    const location = job.location || job.standort || job.city || job.Standort || '';
    const opt = document.createElement('option');
    opt.value = id || title;
    opt.textContent = [id ? `#${id}` : '', title, location].filter(Boolean).join(' · ');
    opt.dataset.jobId = id;
    opt.dataset.jobTitle = title;
    opt.dataset.jobLocation = location;
    if (opt.value === current) opt.selected = true;
    sel.appendChild(opt);
  });
}

window.filterJobs = function() {
  const q = (document.getElementById('in-job-search')?.value || '').toLowerCase();
  const all = window._allJobs || [];
  const filtered = q ? all.filter(j => {
    const id = String(j.id || j.job_id || j.ID || '').toLowerCase();
    const title = (j.title || j.job_title || j.name || j.Titel || '').toLowerCase();
    return id.includes(q) || title.includes(q);
  }) : all;
  renderJobOptions(filtered);
};

// ── Init ──────────────────────────────────────────────────────────────────────
async function init() {

  const testMode = await S.get('test_mode');
  if (testMode) $('chk-test').checked = true;

  const myName = await S.get('my_name') || '';
  const myId = await S.get('my_ownerid') || '';
  if (myName) $('in-my-name').value = myName;
  if (myId) $('in-my-ownerid').value = myId;

  // Jobs webhook
  const jobsUrl = await S.get('jobs_webhook_url');
  if (jobsUrl && $('in-jobs-webhook-url')) $('in-jobs-webhook-url').value = jobsUrl;

  // Bind jobs buttons
  $('btn-load-jobs').addEventListener('click', loadHotJobs);
  $('btn-save-jobs-webhook').addEventListener('click', async () => {
    const url = $('in-jobs-webhook-url').value.trim();
    if (!url) { toast('Bitte URL eingeben', 'err'); return; }
    await S.set('jobs_webhook_url', url);
    toast('Jobs-Webhook gespeichert ✓');
    $('jobs-webhook-status').innerHTML = '<span style="color:#4ade80">✓ Gespeichert</span>';
  });

  // Load cached jobs if available
  const cachedJobs = await S.get('cached_jobs');
  const loadedAt = await S.get('jobs_loaded_at') || 0;
  if (cachedJobs?.length && (Date.now() - loadedAt < 24 * 60 * 60 * 1000)) {
    const sel = $('sel-jobtitle');
    window._allJobs = cachedJobs;
    renderJobOptions(cachedJobs);
    $('jobs-status').innerHTML = `<span style="color:#4ade80">✓ ${cachedJobs.length} Jobs (gecacht)</span>`;
  }

  await loadTeam();




}

checkAuth();

// Bind test button (settings tab)
document.addEventListener('click', e => {
  if (e.target && e.target.id === 'btn-test-all-webhooks') {
    testAllWebhooks();
  }
});
